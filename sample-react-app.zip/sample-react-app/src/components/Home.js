import React, { Fragment } from 'react';
import { Button, Table } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Employees from "./Employees";
import { Link, useNavigate } from 'react-router-dom'; 

function Home() {
  let history = useNavigate();

  const handleEdit = (id, Name, Skills, Designation, Age) => {
    localStorage.setItem('Name', Name);
    localStorage.setItem('Skills', Skills);
    localStorage.setItem('Designation', Designation);
    localStorage.setItem('Age', Age);
    localStorage.setItem('Id', id);
  }

  const handleDelete = (id) => {
    var index = Employees.map(function (e) {
      return e.id
    }).indexOf(id);

    Employees.splice(index, 1);
    console.log(`Employee with id ${id} deleted`);
    history('/');
  }

  return (
    <Fragment>
      <div style={{ margin: "10rem" }}>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Name</th>
              <th>Skills</th>
              <th>Designation</th>
              <th>Age</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {
              Employees && Employees.length > 0
                ?
                Employees.map((item) => {
                  return (
                    <tr key={item.id}>
                      <td>{item.Name}</td>
                      <td>{item.Skills}</td>
                      <td>{item.Designation}</td>
                      <td>{item.Age}</td>
                      <td>
                      <Link to={`/edit/${item.id}`}>
                        <Button onClick={() => handleEdit(item.id, item.Name, item.Skills, item.Designation, item.Age)}>Edit</Button>
                      </Link>

                        &nbsp;
                        <Button onClick={() => { handleDelete(item.id); }}>Delete</Button>
                      </td>
                    </tr>
                  )
                })
                :
                "No data available"
            }
          </tbody>
        </Table>
        <br />
        <Link className='d-grid gap-2' to="/create">
          <Button size="lg">Create</Button>
        </Link>
      </div>
    </Fragment>
  )
}

export default Home;



// import React, { Fragment, useMemo } from 'react';
// import { useTable } from 'react-table'; 
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Employees from "./Employees";
// import { Button, Table } from 'react-bootstrap';
// import { Link, useNavigate } from 'react-router-dom';

// function Home() {
//   const columns = useMemo(() => [
//     { Header: 'Name', accessor: 'Name' },
//     { Header: 'Skills', accessor: 'Skills' },
//     { Header: 'Designation', accessor: 'Designation' },
//     { Header: 'Age', accessor: 'Age' },
//     {
//       Header: 'Actions',
//       Cell: ({ row }) => (
//         <>
//           <Link to={`/edit/${row.original.id}`}>
//             <Button>Edit</Button>
//           </Link>
//           &nbsp;
//           <Button onClick={() => handleDelete(row.original.id)}>Delete</Button>
//         </>
//       ),
//     },
//   ], []);

//   const data = useMemo(() => Employees, []);

//   const {
//     getTableProps,
//     getTableBodyProps,
//     headerGroups,
//     rows,
//     prepareRow,
//   } = useTable({ columns, data });

//   let history = useNavigate();

//   const handleDelete = (id) => {
//     const updatedEmployees = Employees.filter((employee) => employee.id !== id);
//     console.log(`Employee with id ${id} deleted`);
    
//     setEmployees(updatedEmployees);
//     history('/');
//   }


//   return (
//     <Fragment>
//       <div style={{ margin: "10rem" }}>
//         <Table striped bordered hover size="sm" {...getTableProps()}>
//           <thead>
//             {headerGroups.map(headerGroup => (
//               <tr {...headerGroup.getHeaderGroupProps()}>
//                 {headerGroup.headers.map(column => (
//                   <th {...column.getHeaderProps()}>{column.render('Header')}</th>
//                 ))}
//               </tr>
//             ))}
//           </thead>
//           <tbody {...getTableBodyProps()}>
//             {rows.map(row => {
//               prepareRow(row);
//               return (
//                 <tr key={row.id} {...row.getRowProps()}>
//                   {row.cells.map(cell => (
//                     <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
//                   ))}
//                 </tr>
//               );
//             })}
//           </tbody>
//         </Table>
//         <br />
//         <Link className='d-grid gap-2' to="/create">
//           <Button size="lg">Create</Button>
//         </Link>
//       </div>
//     </Fragment>
//   );
// }

// export default Home;
