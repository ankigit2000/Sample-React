import React, { useState } from 'react';
import { Button, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Employees from "./Employees";
import { v4 as uuid } from "uuid";
import { Link, useNavigate } from 'react-router-dom';

function Add() {
  const [name, setName] = useState('');
  const [skills, setSkills] = useState('');
  const [designation, setDesignation] = useState('');
  const [age, setAge] = useState('');

  let history = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    const ids = uuid();
    let uniqueId = ids.slice(0, 8);
    let EmployeeName = name,
      EmployeeSkills = skills,
      EmployeeDesignation = designation,
      EmployeeAge = age;

    Employees.push({ id: uniqueId, Name: EmployeeName, Skills: EmployeeSkills, Designation: EmployeeDesignation, Age: EmployeeAge });
    console.log(`Employee added: ${JSON.stringify(Employees[Employees.length - 1])}`);
    history("/");
  }

  return (
    <div>
      <Form className="d-grid gap-2" style={{ margin: "15rem" }}>
        <Form.Group className="mb-3" controlId="FormName">
          <Form.Control type="text" placeholder="Enter Name" required onChange={(e) => setName(e.target.value)}>
          </Form.Control>
        </Form.Group>
        <Form.Group className="mb-3" controlId="FormSkills">
          <Form.Control type="text" placeholder="Enter Skills" required onChange={(e) => setSkills(e.target.value)}>
          </Form.Control>
        </Form.Group>
        <Form.Group className="mb-3" controlId="FormDesignation">
          <Form.Control type="text" placeholder="Enter Designation" required onChange={(e) => setDesignation(e.target.value)}>
          </Form.Control>
        </Form.Group>
        <Form.Group className="mb-3" controlId="FormAge">
          <Form.Control type="text" placeholder="Enter Age" required onChange={(e) => setAge(e.target.value)}>
          </Form.Control>
        </Form.Group>
        <Button onClick={(e) => handleSubmit(e)} type="submit">Submit</Button>
      </Form>
    </div>
  )
}

export default Add;
