const Employees = [
    {
        id:"1",
        Name: "Anil",
        Skills : "Angular",
        Designation : "Web Developer",
        Age : 26
    },
    {
        id:"2",
        Name: "Balaji A M",
        Skills : "DotNet",
        Designation : "Back-End Developer",
        Age : 29
    },
    {
        id:"3",
        Name: "Vishnu Vijayan",
        Skills : "React",
        Designation : "Web Developer",
        Age : 30
    }
]

export default Employees;