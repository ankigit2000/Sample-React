import React, { useState, useEffect } from 'react';
import { Button, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Employees from "./Employees";
import { useNavigate, useParams } from 'react-router-dom';

function Edit() {
  const { id } = useParams();
  const [name, setName] = useState('');
  const [skills, setSkills] = useState('');
  const [designation, setDesignation] = useState('');
  const [age, setAge] = useState('');

  let history = useNavigate();

  useEffect(() => {
    const employee = Employees.find(emp => emp.id === id);
    if (employee) {
      setName(employee.Name);
      setSkills(employee.Skills);
      setDesignation(employee.Designation);
      setAge(employee.Age);
    }
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    var index = Employees.map(function (e) {
      return e.id
    }).indexOf(id);

    let a = Employees[index];
    a.Name = name;
    a.Skills = skills;
    a.Designation = designation;
    a.Age = age;

    console.log(`Employee updated: ${JSON.stringify(a)}`);
    history("/");
  }

  return (
    <div>
      <Form className="d-grid gap-2" style={{ margin: "15rem" }}>
        <Form.Group className="mb-3" controlId="FormName">
          <Form.Control type="text" placeholder="Enter Name" value={name} required onChange={(e) => setName(e.target.value)}>
          </Form.Control>
        </Form.Group>
        <Form.Group className="mb-3" controlId="FormSkills">
          <Form.Control type="text" placeholder="Enter Skills" value={skills} required onChange={(e) => setSkills(e.target.value)}>
          </Form.Control>
        </Form.Group>
        <Form.Group className="mb-3" controlId="FormDesignation">
          <Form.Control type="text" placeholder="Enter Designation" value={designation} required onChange={(e) => setDesignation(e.target.value)}>
          </Form.Control>
        </Form.Group>
        <Form.Group className="mb-3" controlId="FormAge">
          <Form.Control type="text" placeholder="Enter Age" value={age} required onChange={(e) => setAge(e.target.value)}>
          </Form.Control>
        </Form.Group>
        <Button onClick={(e) => handleSubmit(e)} type="submit">Update</Button>
      </Form>
    </div>
  )
}

export default Edit;
